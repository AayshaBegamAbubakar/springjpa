package com.stock.stockexchange.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.service.SectorService;

@RestController
@RequestMapping("/companyController")
public class CompanyController {

	@Autowired
	SectorService sectorService;

	
	@GetMapping("/getCompany/{id}")
	public List<Sector> getCompany(@PathVariable("id") int id) {
		System.out.println("get Company List  with sector id = " + id + "...");

		List<Sector> sectorData = sectorService.findBySectorId(id);

		return sectorData;
	}


}
